#!/usr/bin/env python3
# Edita el index.html del radar (repo calcagnoagustin/radar, docs/index.html):
#  1) % de cada trade calculado desde pnl_net/(entry*cantidad) -> consistente con el $.
#  2) "Ver mas" en AMBOS historiales (Semillas y Ganesha): muestra 8, despliega el resto.
# Reutiliza dashboard.gh_put (maneja sha). Asserts frenan antes de publicar si algo no matchea.
import requests
import dashboard

RAW = "https://raw.githubusercontent.com/calcagnoagustin/radar/main/docs/index.html"


def main():
    html = requests.get(RAW, timeout=20).text
    orig = html

    # 1) FIX % (2 ocurrencias identicas: Semillas y Ganesha)
    old_pct = "const pnl=t.pnl_net||0;const pct=t.entry?((t.exit/t.entry-1)*100):0;"
    new_pct = "const pnl=t.pnl_net||0;const _cb=(t.entry||0)*(t.qty_total||0);const pct=_cb?(pnl/_cb*100):0;"
    assert html.count(old_pct) == 2, "pct anchors=%d" % html.count(old_pct)
    html = html.replace(old_pct, new_pct)

    # 2) helper paginateHist (global, una vez) tras la def de fmtPct
    anchor = 'const fmtPct=n=>(n>=0?"+":"")+n.toFixed(2)+"%";'
    assert html.count(anchor) == 1, "fmtPct anchor=%d" % html.count(anchor)
    fn = (
        "\nfunction paginateHist(cid,lim){var c=document.getElementById(cid);if(!c)return;"
        "var rows=Array.prototype.slice.call(c.querySelectorAll('.trade'));if(rows.length<=lim)return;"
        "rows.forEach(function(r,i){if(i>=lim)r.classList.add('tr-hidden');});"
        "var rest=rows.length-lim;var w=document.createElement('div');w.style.textAlign='center';"
        "var btn=document.createElement('button');btn.className='vermas';"
        "btn.textContent='Ver m\\u00e1s ('+rest+')';btn.dataset.exp='0';"
        "btn.addEventListener('click',function(){"
        "if(btn.dataset.exp==='0'){c.querySelectorAll('.trade.tr-hidden').forEach(function(e){e.classList.remove('tr-hidden');});"
        "btn.textContent='Ver menos';btn.dataset.exp='1';}"
        "else{Array.prototype.slice.call(c.querySelectorAll('.trade')).forEach(function(e,i){if(i>=lim)e.classList.add('tr-hidden');});"
        "btn.textContent='Ver m\\u00e1s ('+rest+')';btn.dataset.exp='0';}});"
        "w.appendChild(btn);c.appendChild(w);}"
    )
    html = html.replace(anchor, anchor + fn)

    # 3) llamadas tras cada forEach
    a_s = "    shc.appendChild(el);\n  });"
    assert html.count(a_s) == 1, "semillas foreach=%d" % html.count(a_s)
    html = html.replace(a_s, a_s + '\n  paginateHist("sHistory",8);')
    a_g = "      hc.appendChild(el);\n    });"
    assert html.count(a_g) == 1, "ganesha foreach=%d" % html.count(a_g)
    html = html.replace(a_g, a_g + '\n    paginateHist("gHistory",8);')

    # 4) CSS
    css = ".trade .tr-pct{font-size:12px}"
    assert html.count(css) == 1, "css anchor=%d" % html.count(css)
    html = html.replace(css, css + (
        "\n  .tr-hidden{display:none}"
        "\n  .vermas{margin-top:12px;background:transparent;border:1px solid #2a3b32;color:#9fe0b8;"
        "font:inherit;font-size:12px;padding:7px 16px;border-radius:8px;cursor:pointer;width:100%}"
        "\n  .vermas:hover{background:#16241c}"
    ))

    assert html != orig, "sin cambios"
    dashboard.gh_put("docs/index.html", html.encode("utf-8"),
                     "fix % (pnl-based) + Ver mas paginacion en ambos radares")
    print("PUSHED ok, len", len(html))


if __name__ == "__main__":
    main()
