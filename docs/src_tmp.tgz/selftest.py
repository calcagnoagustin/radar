#!/usr/bin/env python3
"""Autotest del Sistema Semillas — NO requiere API keys ni toca saldo.

Usa la API PÚBLICA de Binance (precios/velas) para:
  - confirmar conectividad real con el exchange,
  - correr los indicadores Weinstein/Wyckoff sobre datos reales,
  - simular el motor de decisión sobre cada símbolo,
  - armar un reporte de muestra.

Uso: python selftest.py
"""
import sys
import ccxt
import config
import indicators as ind
import strategy

SYMBOLS = ["PENDLE/USDT", "WLD/USDT", "DOGE/USDT", "LINK/USDT"]


def main():
    print("=" * 56)
    print(" SISTEMA SEMILLAS 2.0 — AUTOTEST (sin keys, sin riesgo)")
    print("=" * 56)
    print(f" Parámetros: MA={config.MA_PERIOD}  confirm={config.CONFIRM_DAYS}d"
          f"  slope={config.SLOPE_LOOKBACK}")
    print("-" * 56)

    client = ccxt.binance({"enableRateLimit": True,
                           "options": {"defaultType": "spot"}})
    try:
        client.load_markets()
    except Exception as e:
        print(f"[FALLO] No se pudo conectar a Binance público: {e}")
        sys.exit(1)
    print("[OK] Conexión con Binance (API pública) establecida.\n")

    stage_names = {2: "Stage 2 (alcista)", 4: "Stage 4 (bajista)",
                   3: "transición", 1: "base/lateral", None: "sin datos"}

    for sym in SYMBOLS:
        try:
            ohlcv = client.fetch_ohlcv(sym, "1d", limit=config.MA_PERIOD + 40)
        except Exception as e:
            print(f"{sym:14} -> sin datos ({e})")
            continue
        price = ind.closes(ohlcv)[-1]
        st = ind.stage(ohlcv, config.MA_PERIOD, config.SLOPE_LOOKBACK)
        wk = ind.pct_return(ind.closes(ohlcv), 7)
        vspike = ind.volume_spike(ohlcv)

        # simulo una posición semilla recién plantada para ver qué decidiría
        pos = {"status": "seed", "planted_at": "2026-06-18",
               "qty": 1.0, "avg_cost": price, "dca_adds": 0, "tp_hit": []}
        action = strategy.decide(sym, ohlcv, pos)

        print(f"{sym:14} ${price:<11.4f} {stage_names.get(st):18}"
              f" 7d:{wk:+6.1f}%  vol:{vspike:4.1f}x  -> {action['type']}")

    print("\n[OK] Indicadores y motor de decisión corrieron sobre datos reales.")
    print("[OK] El sistema está listo. Falta cargar las API keys para operar.")


if __name__ == "__main__":
    main()
